# Advoc8 custom contact details

Interactive Albanese profile prototype matching the annotated Figma flow, with close buttons in modal headers.

Run locally: `python3 -m http.server 8000`. GitHub Pages serves the main branch root.

Sample contacts are browser-only and reset on refresh. Team notes use neutral sample content. There are no production writes.
