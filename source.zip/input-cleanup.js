// Keep password-manager decorations out of these non-login prototype forms.
(() => {
  const dialog = document.querySelector('#detail-dialog');
  if (!dialog) return;
  const removeDecorations = () => {
    dialog.querySelectorAll('[data-lastpass-icon-root]').forEach(element => element.remove());
  };
  const observer = new MutationObserver(changes => {
    if (changes.some(change => change.addedNodes.length)) removeDecorations();
  });
  observer.observe(dialog, { childList: true, subtree: true });
  removeDecorations();
})();
