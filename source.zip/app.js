(() => {
  const card = document.querySelector('#exact-details');
  const dialog = document.querySelector('#detail-dialog');
  const status = document.querySelector('#flow-status');
  const managedContent = document.querySelector('#managed-details-template').innerHTML;
  const assets = 'assets/ui/';
  const esc = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const icon = (name, upright = false) => `<span class="exact-icon${upright ? ' upright' : ''}" aria-hidden="true"><img src="${assets}${name}.svg" alt=""></span>`;
  const tooltip = (text, id, copy = false) => `<span role="tooltip" id="${id}" class="${copy ? 'copy-tooltip' : 'icon-tooltip'}">${text}<img class="${copy ? 'copy-tooltip-arrow' : 'tooltip-arrow'}" src="${assets}${copy ? 'copy-arrow' : 'tooltip-arrow'}.svg" alt=""></span>`;
  let records = [], sequence = 0, menu = null, returnTo = null;
  const kindOrder = {email: 0, phone: 1, address: 2};
  const ordered = () => [...records].sort((a, b) => kindOrder[a.kind] - kindOrder[b.kind] || a.order - b.order);
  const announce = message => { status.textContent = message; };

  function copyControl(value, id) {
    return `<button type="button" class="detail-value copy-trigger" data-copy="${esc(value)}" aria-describedby="${id}"><span class="copy-text">${esc(value)}</span><span class="copy-icon" aria-hidden="true"><img src="${assets}copy-blue.svg" alt=""></span>${tooltip('Copy to Clipboard', id, true)}</button>`;
  }

  function ownershipBadge(managed = true) {
    const name = managed ? 'badge-logo' : 'badge-lock';
    return `<span class="ownership-badge${managed ? '' : ' tooltip-trigger'}"${managed ? '' : ' tabindex="0" aria-describedby="custom-visibility"'}><span class="badge-icon"><img src="${assets}${name}.svg" alt=""></span>${managed ? 'Managed by Advoc8' : 'Managed by you'}${managed ? '' : tooltip('Only visible to team', 'custom-visibility')}</span>`;
  }

  function addDetails() {
    return `<div class="exact-anchor add-details-anchor"><button type="button" class="exact-button" data-add aria-haspopup="menu" aria-expanded="${menu === 'add'}">${icon('plus')}Add details${icon('chevron')}</button>${menu === 'add' ? `<div class="exact-menu add-details-menu" role="menu" aria-label="Add custom details"><button role="menuitem" type="button" data-kind="email">${icon('mail')}Email</button><button role="menuitem" type="button" data-kind="phone">${icon('phone')}Phone number</button><button role="menuitem" type="button" data-kind="address">${icon('address-map')}Address</button></div>` : ''}</div>`;
  }

  function render() {
    card.classList.toggle('has-custom-details', records.length > 0);
    card.innerHTML = `<div class="detail-heading"><h2>Details</h2>${ownershipBadge()}</div><div class="managed-details-content">${managedContent}</div><div class="detail-actions"><button type="button" class="suggest-link" data-suggest><span class="suggest-icon" aria-hidden="true"><img src="${assets}suggest-body.svg" alt=""><img src="${assets}suggest-lines.svg" alt=""></span>Suggest an update</button>${records.length ? '' : addDetails()}</div>${records.length ? `<div class="detail-heading custom-heading"><h2>Custom details</h2>${ownershipBadge(false)}</div>${ordered().map(r => `<div class="detail-line private-row${r.kind === 'address' ? ' address-row' : ''}" data-record="${r.id}" data-kind-group="${r.kind}"><span class="detail-label">${esc(r.label)}</span>${r.kind === 'address' ? addressControl(r) : copyControl(r.value, 'copy-' + r.id)}<div class="exact-anchor"><button type="button" class="exact-button row-more" data-more="${r.id}" aria-label="Actions for ${esc(r.label)}" aria-haspopup="menu" aria-expanded="${menu === r.id}">${icon('more')}</button>${menu === r.id ? `<div class="exact-menu row-menu" role="menu" aria-label="${esc(r.label)} actions"><button type="button" role="menuitem" data-edit="${r.id}">${icon('edit')}Edit</button><button type="button" role="menuitem" data-delete="${r.id}">${icon('trash', true)}Delete</button></div>` : ''}</div></div>`).join('')}<div class="detail-actions custom-actions">${addDetails()}</div>` : ''}`;
    card.querySelectorAll('.managed-details-content [data-copy]').forEach((control, index) => {
      control.classList.add('copy-trigger');
      control.removeAttribute('title');
      control.querySelector('i')?.remove();
      const id = 'managed-copy-' + index;
      control.insertAdjacentHTML('beforeend', `<span class="copy-icon" aria-hidden="true"><img src="${assets}copy-blue.svg" alt=""></span>${tooltip('Copy to Clipboard', id, true)}`);
      control.setAttribute('aria-describedby', id);
    });
  }

  function restoreFocus() {
    if (returnTo?.selector) {
      document.querySelector(returnTo.selector)?.focus({ preventScroll: true });
      return;
    }
    const selector = returnTo?.id ? `[data-more="${returnTo.id}"]` : '[data-add]';
    (card.querySelector(selector) || card.querySelector('[data-add]')).focus({ preventScroll: true });
  }

  function closeMenu(focus = true) {
    const previous = menu;
    menu = null;
    render();
    if (focus) (card.querySelector(previous === 'add' ? '[data-add]' : `[data-more="${previous}"]`) || card.querySelector('[data-add]')).focus({ preventScroll: true });
  }

  function openMenu(id) {
    if (menu === id) return closeMenu();
    menu = id;
    render();
    card.querySelector('[role="menuitem"]').focus({ preventScroll: true });
  }

  function showForm(kind, id = null) {
    if (kind === 'address') return showAddressForm(id);
    dialog.classList.remove('address-dialog');
    dialog.oncancel = null;
    const record = records.find(r => r.id === id), email = kind === 'email';
    menu = null; returnTo = { id }; render();
    dialog.innerHTML = `<h2 id="dialog-title">Add ${email ? 'an email' : 'a phone number'}<button type="button" class="dialog-close" data-close aria-label="Close">×</button></h2><form id="private-form"><p>This will only be visible to your team.</p><div class="exact-fields"><label for="private-label">${email ? 'Email' : 'Phone'} label<span class="label-control"><input id="private-label" name="label" placeholder="${email ? 'E.g. Private email' : 'E.g. Private mobile'}" value="${esc(record?.label || '')}" required maxlength="80" autocomplete="off" data-lpignore="true" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="label-suggestions"><span id="label-suggestions" role="listbox" aria-label="Previously used labels" hidden></span></span></label><label for="private-value">${email ? 'Email address' : 'Phone number'}<input id="private-value" name="value" type="${email ? 'email' : 'tel'}" placeholder="${email ? 'Add an email' : 'Add a phone number'}" value="${esc(record?.value || '')}" required autocomplete="off" data-lpignore="true"></label></div><button type="submit" class="exact-button primary">Save changes</button></form>`;
    setupLabelSuggestions(kind);
    dialog.showModal();
    if (record) dialog.querySelector('#private-value').focus(); else dialog.focus();
    dialog.querySelector('form').onsubmit = event => {
      event.preventDefault();
      const label = dialog.querySelector('#private-label').value.trim(), value = dialog.querySelector('#private-value').value.trim();
      if (!label || !value) return;
      rememberLabel(kind, label);
      if (record) Object.assign(record,{label,value}); else records.push({id:crypto.randomUUID(),kind,label,value,order:sequence++});
      dialog.close();render();restoreFocus();announce('Custom detail saved.');
    };
  }

  const addressTypes = ['Electorate (street)', 'Electorate (postal)', 'Parliament (street)', 'Parliament (postal)', 'Office Address', 'Postal Address', 'Residential Address'];

  function addressLines(record) {
    return [record.type, record.line1, record.line2, record.line3,
      [record.city, record.state, record.postcode].filter(Boolean).join(' '),
      record.country, record.phone ? 'P: ' + record.phone : ''].filter(Boolean);
  }

  function addressControl(record) {
    const lines = addressLines(record);
    return `<button type="button" class="detail-value copy-trigger address-value" data-copy="${esc(lines.join('\n'))}" aria-describedby="copy-${record.id}"><span class="copy-text"><strong>${esc(lines[0])}</strong>${lines.slice(1).map(line => `<span>${esc(line)}</span>`).join('')}</span><span class="copy-icon" aria-hidden="true"><img src="${assets}copy-blue.svg" alt=""></span>${tooltip('Copy to Clipboard', 'copy-' + record.id, true)}</button>`;
  }

  function showAddressForm(id = null) {
    const record = records.find(r => r.id === id);
    menu = null; returnTo = {id}; render();
    dialog.classList.add('address-dialog');
    dialog.oncancel = null;
    const field = (name, label, placeholder = '', required = false, inputType = 'text') => `<label for="address-${name}">${label}<input id="address-${name}" name="${name}" type="${inputType}" value="${esc(record?.[name] || '')}" placeholder="${placeholder}" ${required ? 'required' : ''} autocomplete="off" data-lpignore="true"></label>`;
    dialog.innerHTML = `<h2 id="dialog-title">${record ? 'Edit Address' : 'New Address'}<button type="button" class="dialog-close" data-close aria-label="Close">×</button></h2><form id="address-form"><p>This will only be visible to your team.</p><div class="address-identification">${field('label', 'Address name', 'E.g. Head Office', true)}<label for="address-type">Address type<span class="label-control"><input id="address-type" name="type" aria-label="Address type" value="${esc(record?.type || '')}" placeholder="E.g. Alternate Street Address" required autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="address-type-suggestions"><span id="address-type-suggestions" class="field-suggestions" role="listbox" aria-label="Address types" hidden></span></span><button type="button" class="new-address-type" data-new-type>Add new address type</button></label></div><label class="address-primary"><input type="checkbox" name="primary" role="switch" ${record?.primary ? 'checked' : ''}><span class="switch-indicator" aria-hidden="true"><img src="${assets}address-switch.svg" alt=""><span></span></span><span>Primary address for this type</span></label>${field('line1', 'Line 1', '3 Example Street, Parkville VIC 3052', true)}${field('line2', 'Line 2')}${field('line3', 'Line 3')}<div class="address-locality">${field('city', 'City')}${field('state', 'State')}${field('postcode', 'Postcode')}${field('country', 'Country')}</div>${field('phone', 'Phone', '', false, 'tel')}<button type="submit" class="exact-button primary">Save changes</button></form>`;
    setupAddressTypes();
    dialog.showModal();
    dialog.focus();
    dialog.querySelector('form').onsubmit = event => {
      event.preventDefault();
      const data = new FormData(event.currentTarget), values = {};
      for (const name of ['label', 'type', 'line1', 'line2', 'line3', 'city', 'state', 'postcode', 'country', 'phone']) values[name] = String(data.get(name) || '').trim();
      if (!values.label || !values.type || !values.line1) return;
      values.primary = data.has('primary');
      if (values.primary) records.filter(r => r.kind === 'address' && r.type.toLowerCase() === values.type.toLowerCase()).forEach(r => { r.primary = false; });
      if (!addressTypes.some(t => t.toLowerCase() === values.type.toLowerCase())) addressTypes.push(values.type);
      if (record) Object.assign(record, values); else records.push({id: crypto.randomUUID(), kind: 'address', order: sequence++, ...values});
      dialog.close(); render(); restoreFocus(); announce('Custom address saved.');
    };
  }

  function setupAddressTypes() {
    const input = dialog.querySelector('#address-type'), list = dialog.querySelector('#address-type-suggestions'), add = dialog.querySelector('[data-new-type]');
    let matches = [], active = 0;
    const close = () => { list.hidden = true; input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); };
    const choose = index => { input.value = matches[index]; close(); dialog.querySelector('#address-line1').focus(); };
    const draw = () => {
      matches = addressTypes.filter(type => type.toLowerCase().includes(input.value.trim().toLowerCase()));
      active = 0;
      list.innerHTML = matches.map((type, i) => `<span role="option" id="address-type-option-${i}" data-option="${i}" aria-selected="${i === 0}">${esc(type)}</span>`).join('');
      list.hidden = !matches.length;
      input.setAttribute('aria-expanded', String(!!matches.length));
      if (matches.length) input.setAttribute('aria-activedescendant', 'address-type-option-0'); else input.removeAttribute('aria-activedescendant');
    };
    input.addEventListener('focus', draw);
    input.addEventListener('input', draw);
    input.addEventListener('blur', close);
    input.addEventListener('keydown', event => {
      if (list.hidden || !['ArrowDown', 'ArrowUp', 'Enter', 'Escape'].includes(event.key)) return;
      event.preventDefault(); event.stopPropagation();
      if (event.key === 'Escape') return close();
      if (event.key === 'Enter') return choose(active);
      active = (active + (event.key === 'ArrowDown' ? 1 : -1) + matches.length) % matches.length;
      [...list.children].forEach((option, i) => option.setAttribute('aria-selected', String(i === active)));
      input.setAttribute('aria-activedescendant', 'address-type-option-' + active);
    });
    list.addEventListener('mousedown', event => event.preventDefault());
    list.addEventListener('click', event => { const option = event.target.closest('[data-option]'); if (option) choose(Number(option.dataset.option)); });
    add.onclick = () => {
      input.focus(); close(); input.select(); input.placeholder = 'Enter a new address type';
      announce('Enter a new address type. It will be added when you save this address.');
    };
    dialog.oncancel = event => { if (!list.hidden) {event.preventDefault(); close();} };
  }

  const labelHistoryKey = 'advoc8-prototype-label-history';
  const labelHistory = {email: ['Personal email', 'Private email', 'Petersham office', 'Peter’s email'], phone: ['Office phone', 'Oberon mobile', 'Olivia’s assistant', 'Other mobile']};
  try {
    const saved = JSON.parse(localStorage.getItem(labelHistoryKey) || '{}');
    for (const kind of ['email', 'phone']) if (Array.isArray(saved[kind])) labelHistory[kind] = [...new Set([...saved[kind].filter(v => typeof v === 'string'), ...labelHistory[kind]])];
  } catch { /* Suggestions still work when local storage is unavailable. */ }

  function rememberLabel(kind, label) {
    if (!labelHistory[kind].some(v => v.toLowerCase() === label.toLowerCase())) labelHistory[kind].unshift(label);
    try { localStorage.setItem(labelHistoryKey, JSON.stringify(labelHistory)); } catch {}
  }

  function setupLabelSuggestions(kind) {
    const input = dialog.querySelector('#private-label'), list = dialog.querySelector('#label-suggestions');
    let matches = [], active = 0;
    const close = () => { list.hidden = true; input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); };
    const draw = () => {
      const query = input.value.trim().toLowerCase();
      matches = query ? labelHistory[kind].filter(label => label.toLowerCase().startsWith(query)).slice(0, 6) : [];
      active = 0;
      list.innerHTML = matches.map((label, i) => `<span role="option" id="label-option-${i}" data-option="${i}" aria-selected="${i === active}">${esc(label)}</span>`).join('');
      list.hidden = !matches.length;
      input.setAttribute('aria-expanded', String(!!matches.length));
      if (matches.length) input.setAttribute('aria-activedescendant', 'label-option-0'); else input.removeAttribute('aria-activedescendant');
    };
    const choose = index => { input.value = matches[index]; close(); dialog.querySelector('#private-value').focus(); };
    input.addEventListener('input', draw);
    input.addEventListener('focus', draw);
    input.addEventListener('blur', close);
    input.addEventListener('keydown', event => {
      if (list.hidden) return;
      if (['ArrowDown', 'ArrowUp', 'Enter', 'Escape'].includes(event.key)) {
        event.preventDefault(); event.stopPropagation();
        if (event.key === 'Escape') return close();
        if (event.key === 'Enter') return choose(active);
        active = (active + (event.key === 'ArrowDown' ? 1 : -1) + matches.length) % matches.length;
        [...list.children].forEach((option, i) => option.setAttribute('aria-selected', String(i === active)));
        input.setAttribute('aria-activedescendant', 'label-option-' + active);
      }
    });
    list.addEventListener('mousedown', event => event.preventDefault());
    list.addEventListener('click', event => { const option = event.target.closest('[data-option]'); if (option) choose(Number(option.dataset.option)); });
    dialog.oncancel = event => { if (!list.hidden) { event.preventDefault(); close(); } };
  }

  async function copyDetail(control) {
    const original = control.innerHTML;
    try {
      await navigator.clipboard.writeText(control.dataset.copy);
      control.classList.add('is-copied');
      control.innerHTML = `<img class="copied-check" src="${assets}check.svg" alt="">Copied!`;
      announce('Copied to Clipboard');
      setTimeout(() => { if (control.isConnected) { control.innerHTML = original; control.classList.remove('is-copied'); } }, 1200);
    } catch { announce('Unable to copy. Please select and copy the detail.'); }
  }

  function showSuggestion(selector) {
    dialog.classList.remove('address-dialog');
    dialog.oncancel = null;
    returnTo = { selector };
    dialog.innerHTML = '<h2 id="dialog-title">Suggest update<button type="button" class="dialog-close" data-close aria-label="Close">×</button></h2><form><textarea aria-label="Suggested update" placeholder="What needs updating?" required></textarea><button type="submit" class="exact-button primary">Send</button></form>';
    dialog.showModal();
    dialog.querySelector('form').onsubmit = event => { event.preventDefault(); dialog.close(); announce('Suggestion saved in this prototype.'); };
  }

  card.addEventListener('click', event => {
    const control = event.target.closest('button,[data-copy]');
    if (!control) return;
    event.preventDefault();
    event.stopPropagation();
    if (control.hasAttribute('data-add')) openMenu('add');
    else if (control.dataset.kind) showForm(control.dataset.kind);
    else if (control.dataset.more) openMenu(control.dataset.more);
    else if (control.dataset.edit) { const r = records.find(r => r.id === control.dataset.edit); showForm(r.kind, r.id); }
    else if (control.dataset.delete) {
      const record = records.find(r => r.id === control.dataset.delete);
      records = records.filter(r => r.id !== record.id);
      menu = null;
      returnTo = null;
      render();
      restoreFocus();
      announce('Custom detail deleted.');
    } else if (control.dataset.copy) copyDetail(control);
    else if (control.hasAttribute('data-suggest')) {
      // Suggest-update is outside the supplied contact flow; retain the existing local mock.
      showSuggestion('[data-suggest]');
    }
  });

  document.addEventListener('click', event => {
    if (event.target.closest('[data-political-suggest]')) showSuggestion('[data-political-suggest]');
    if (menu && !event.target.closest('#exact-details .exact-anchor')) closeMenu(false);
    if (event.target.closest('a')) event.preventDefault();
  });
  document.addEventListener('submit', event => { if (!event.target.closest('#detail-dialog')) event.preventDefault(); });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      document.querySelectorAll('.tooltip-trigger,.copy-trigger').forEach(t => t.classList.add('tooltip-dismissed'));
      if (menu) { event.preventDefault(); closeMenu(); }
    }
    if (menu && ['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault();
      const items = [...card.querySelectorAll('[role="menuitem"]')];
      let next = items.indexOf(document.activeElement) + (event.key === 'ArrowUp' ? -1 : 1);
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = items.length - 1;
      items[(next + items.length) % items.length].focus();
    }
    if (event.target.matches('[data-copy]:not(button)') && ['Enter', ' '].includes(event.key)) { event.preventDefault(); copyDetail(event.target); }
  });
  document.addEventListener('mouseover', event => {
    const target = event.target.closest('.tooltip-trigger,.copy-trigger');
    if (target && !target.contains(event.relatedTarget)) target.classList.remove('tooltip-dismissed');
  });
  document.addEventListener('focusin', event => event.target.closest('.tooltip-trigger,.copy-trigger')?.classList.remove('tooltip-dismissed'));
  dialog.addEventListener('click', event => {
    if (event.target.closest('[data-close]')) dialog.close();
    if (event.target === dialog) {
      const r = dialog.getBoundingClientRect();
      if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close();
    }
  });
  dialog.addEventListener('close', restoreFocus);
  render();
})();
