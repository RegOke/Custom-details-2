(() => {
  const card = document.querySelector('#exact-details');
  const dialog = document.querySelector('#detail-dialog');
  const status = document.querySelector('#flow-status');
  const managedContent = document.querySelector('#managed-details-template').innerHTML;
  const assets = 'assets/ui/';
  const esc = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const icon = (name, upright = false) => `<span class="exact-icon${upright ? ' upright' : ''}" aria-hidden="true"><img src="${assets}${name}.svg" alt=""></span>`;
  const tooltip = (text, id, copy = false) => `<span role="tooltip" id="${id}" class="${copy ? 'copy-tooltip' : 'icon-tooltip'}">${text}<img class="${copy ? 'copy-tooltip-arrow' : 'tooltip-arrow'}" src="${assets}${copy ? 'copy-arrow' : 'tooltip-arrow'}.svg" alt=""></span>`;
  let records = [], sequence = 0, menu = null, returnTo = null;
  const ordered = () => [...records].sort((a, b) => (a.kind === 'email' ? 0 : 1) - (b.kind === 'email' ? 0 : 1) || a.order - b.order);
  const announce = message => { status.textContent = message; };

  function copyControl(value, id) {
    return `<button type="button" class="detail-value copy-trigger" data-copy="${esc(value)}" aria-describedby="${id}"><span class="copy-text">${esc(value)}</span><span class="copy-icon" aria-hidden="true"><img src="${assets}copy-blue.svg" alt=""></span>${tooltip('Copy to Clipboard', id, true)}</button>`;
  }

  function render() {
    card.innerHTML = `<div class="detail-heading"><h2>Details <span class="exact-brand tooltip-trigger" role="img" tabindex="0" aria-label="Advoc8 management" aria-describedby="managed-tooltip"><img src="${assets}brand.svg" alt="">${tooltip('Managed by Advoc8', 'managed-tooltip')}</span></h2><button type="button" class="exact-button" data-suggest>${icon('message')}Suggest update</button></div><div class="managed-details-content">${managedContent}</div><div class="detail-heading private-heading"><h2>Private details <span class="private-lock tooltip-trigger" role="img" tabindex="0" aria-label="Private details visibility" aria-describedby="private-tooltip"><img src="${assets}lock.svg" alt="">${tooltip('Only visible to team', 'private-tooltip')}</span></h2><div class="exact-anchor"><button type="button" class="exact-button" data-add aria-haspopup="menu" aria-expanded="${menu === 'add'}">${icon('plus')}Add${icon('chevron')}</button>${menu === 'add' ? `<div class="exact-menu" role="menu" aria-label="Add private details"><button role="menuitem" type="button" data-kind="email">${icon('mail')}Email</button><button role="menuitem" type="button" data-kind="phone">${icon('phone')}Phone number</button></div>` : ''}</div></div>${ordered().map(r => `<div class="detail-line private-row" data-record="${r.id}" data-kind-group="${r.kind}"><span class="detail-label">${esc(r.label)}</span>${copyControl(r.value, 'copy-' + r.id)}<div class="exact-anchor"><button type="button" class="exact-button row-more" data-more="${r.id}" aria-label="Actions for ${esc(r.label)}" aria-haspopup="menu" aria-expanded="${menu === r.id}">${icon('more')}</button>${menu === r.id ? `<div class="exact-menu row-menu" role="menu" aria-label="${esc(r.label)} actions"><button type="button" role="menuitem" data-edit="${r.id}">${icon('edit')}Edit</button><button type="button" role="menuitem" data-delete="${r.id}">${icon('trash', true)}Delete</button></div>` : ''}</div></div>`).join('')}`;
    card.querySelectorAll('.managed-details-content [data-copy]').forEach((control, index) => {
      control.classList.add('copy-trigger');
      control.removeAttribute('title');
      control.querySelector('i')?.remove();
      const id = 'managed-copy-' + index;
      control.insertAdjacentHTML('beforeend', `<span class="copy-icon" aria-hidden="true"><img src="${assets}copy-blue.svg" alt=""></span>${tooltip('Copy to Clipboard', id, true)}`);
      control.setAttribute('aria-describedby', id);
    });
  }

  function restoreFocus() {
    if (returnTo?.selector) {
      document.querySelector(returnTo.selector)?.focus({ preventScroll: true });
      return;
    }
    const selector = returnTo?.id ? `[data-more="${returnTo.id}"]` : '[data-add]';
    (card.querySelector(selector) || card.querySelector('[data-add]')).focus({ preventScroll: true });
  }

  function closeMenu(focus = true) {
    const previous = menu;
    menu = null;
    render();
    if (focus) (card.querySelector(previous === 'add' ? '[data-add]' : `[data-more="${previous}"]`) || card.querySelector('[data-add]')).focus({ preventScroll: true });
  }

  function openMenu(id) {
    if (menu === id) return closeMenu();
    menu = id;
    render();
    card.querySelector('[role="menuitem"]').focus({ preventScroll: true });
  }

  function showForm(kind, id = null) {
    const record = records.find(r => r.id === id), email = kind === 'email';
    menu = null; returnTo = { id }; render();
    dialog.innerHTML = `<h2 id="dialog-title">Add ${email ? 'an email' : 'a phone number'}<button type="button" class="dialog-close" data-close aria-label="Close">×</button></h2><form id="private-form"><p>This will only be visible to your team.</p><div class="exact-fields"><label for="private-label">${email ? 'Email' : 'Phone'} label<input id="private-label" name="label" placeholder="${email ? 'E.g. Private email' : 'E.g. Private mobile'}" value="${esc(record?.label || '')}" required maxlength="80" autocomplete="off" data-lpignore="true"></label><label for="private-value">${email ? 'Email address' : 'Phone number'}<input id="private-value" name="value" type="${email ? 'email' : 'tel'}" placeholder="${email ? 'Add an email' : 'Add a phone number'}" value="${esc(record?.value || '')}" required autocomplete="off" data-lpignore="true"></label></div><button type="submit" class="exact-button primary">Save changes</button></form>`;
    dialog.showModal();
    if (record) dialog.querySelector('#private-value').focus(); else dialog.focus();
    dialog.querySelector('form').onsubmit = event => {
      event.preventDefault();
      const label = dialog.querySelector('#private-label').value.trim(), value = dialog.querySelector('#private-value').value.trim();
      if (!label || !value) return;
      if (record) Object.assign(record,{label,value}); else records.push({id:crypto.randomUUID(),kind,label,value,order:sequence++});
      dialog.close();render();restoreFocus();announce('Private detail saved.');
    };
  }

  async function copyDetail(control) {
    const original = control.innerHTML;
    try {
      await navigator.clipboard.writeText(control.dataset.copy);
      control.classList.add('is-copied');
      control.innerHTML = `<img class="copied-check" src="${assets}check.svg" alt="">Copied!`;
      announce('Copied to Clipboard');
      setTimeout(() => { if (control.isConnected) { control.innerHTML = original; control.classList.remove('is-copied'); } }, 1200);
    } catch { announce('Unable to copy. Please select and copy the detail.'); }
  }

  function showSuggestion(selector) {
    returnTo = { selector };
    dialog.innerHTML = '<h2 id="dialog-title">Suggest update<button type="button" class="dialog-close" data-close aria-label="Close">×</button></h2><form><textarea aria-label="Suggested update" placeholder="What needs updating?" required></textarea><button type="submit" class="exact-button primary">Send</button></form>';
    dialog.showModal();
    dialog.querySelector('form').onsubmit = event => { event.preventDefault(); dialog.close(); announce('Suggestion saved in this prototype.'); };
  }

  card.addEventListener('click', event => {
    const control = event.target.closest('button,[data-copy]');
    if (!control) return;
    event.preventDefault();
    event.stopPropagation();
    if (control.hasAttribute('data-add')) openMenu('add');
    else if (control.dataset.kind) showForm(control.dataset.kind);
    else if (control.dataset.more) openMenu(control.dataset.more);
    else if (control.dataset.edit) { const r = records.find(r => r.id === control.dataset.edit); showForm(r.kind, r.id); }
    else if (control.dataset.delete) {
      const record = records.find(r => r.id === control.dataset.delete);
      records = records.filter(r => r.id !== record.id);
      menu = null;
      returnTo = null;
      render();
      restoreFocus();
      announce('Private detail deleted.');
    } else if (control.dataset.copy) copyDetail(control);
    else if (control.hasAttribute('data-suggest')) {
      // Suggest-update is outside the supplied contact flow; retain the existing local mock.
      showSuggestion('[data-suggest]');
    }
  });

  document.addEventListener('click', event => {
    if (event.target.closest('[data-political-suggest]')) showSuggestion('[data-political-suggest]');
    if (menu && !event.target.closest('#exact-details .exact-anchor')) closeMenu(false);
    if (event.target.closest('a')) event.preventDefault();
  });
  document.addEventListener('submit', event => { if (!event.target.closest('#detail-dialog')) event.preventDefault(); });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      document.querySelectorAll('.tooltip-trigger,.copy-trigger').forEach(t => t.classList.add('tooltip-dismissed'));
      if (menu) { event.preventDefault(); closeMenu(); }
    }
    if (menu && ['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault();
      const items = [...card.querySelectorAll('[role="menuitem"]')];
      let next = items.indexOf(document.activeElement) + (event.key === 'ArrowUp' ? -1 : 1);
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = items.length - 1;
      items[(next + items.length) % items.length].focus();
    }
    if (event.target.matches('[data-copy]:not(button)') && ['Enter', ' '].includes(event.key)) { event.preventDefault(); copyDetail(event.target); }
  });
  document.addEventListener('mouseover', event => {
    const target = event.target.closest('.tooltip-trigger,.copy-trigger');
    if (target && !target.contains(event.relatedTarget)) target.classList.remove('tooltip-dismissed');
  });
  document.addEventListener('focusin', event => event.target.closest('.tooltip-trigger,.copy-trigger')?.classList.remove('tooltip-dismissed'));
  dialog.addEventListener('click', event => {
    if (event.target.closest('[data-close]')) dialog.close();
    if (event.target === dialog) {
      const r = dialog.getBoundingClientRect();
      if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) dialog.close();
    }
  });
  dialog.addEventListener('close', restoreFocus);
  render();
})();
